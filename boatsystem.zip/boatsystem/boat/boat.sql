-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2020 at 08:01 AM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `boat`
--

-- --------------------------------------------------------

--
-- Table structure for table `boats`
--

CREATE TABLE `boats` (
  `b_id` int(11) NOT NULL,
  `b_name` varchar(35) NOT NULL,
  `b_cpcty` varchar(35) NOT NULL,
  `b_on` varchar(35) NOT NULL,
  `b_img` varchar(255) NOT NULL,
  `b_price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `boats`
--

INSERT INTO `boats` (`b_id`, `b_name`, `b_cpcty`, `b_on`, `b_img`, `b_price`) VALUES
(43, 'ora jackson', '25', 'rayleigh', '../boat_image/image_2016-02-26-11-33-39_56cfc793b356b.jpg', 3500),
(52, 'saitama', '25', 'dante', '../boat_image/image_2016-02-26-11-33-26_56cfc78667a8b.jpg', 3500),
(53, 'guko', '15', 'Captain Baron', '../boat_image/image_2016-02-26-11-33-58_56cfc7a61410a.jpg', 3000),
(54, 'NARUTO', '25', 'Captain Taer', '../boat_image/image_2016-02-26-11-34-18_56cfc7ba02940.jpg', 3500),
(55, 'HOKAGE', '25', 'Captain Baltazar', '../boat_image/image_2016-02-26-11-34-36_56cfc7cc8ee91.jpg', 3500),
(56, 'BARUTO', '30', 'Captain PATUAL', '../boat_image/image_2016-02-26-11-35-29_56cfc8016ff83.jpg', 4000),
(57, 'HENATA', '30', 'Captain MakoyKo', '../boat_image/image_2016-02-26-11-35-54_56cfc81a68825.jpg', 4000),
(58, 'SABUZA', '15', 'Captain Ricardo', '../boat_image/1.JPG', 3000),
(59, 'JENOS', '15', 'Captain Cabilan', '../boat_image/image_2016-02-26-11-36-31_56cfc83f7633d.jpg', 3000),
(60, 'SAZUKI', '15', 'Captain Kevin', '../boat_image/image_2016-02-26-11-36-50_56cfc85230c90.jpg', 3000),
(61, 'RAINBOW', '15', 'Captain Eric', '../boat_image/image_2016-02-26-11-36-58_56cfc85a5d528.jpg', 3000),
(62, 'LAYLA', '15', 'Captain Perwisyo', '../boat_image/image_2016-02-26-13-07-07_56cfdd7bc03a9.jpg', 3000);

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `r_id` int(11) NOT NULL,
  `b_id` int(11) NOT NULL,
  `tour_id` int(11) NOT NULL,
  `r_dstntn` varchar(35) NOT NULL,
  `r_date` varchar(35) NOT NULL,
  `r_hr` varchar(35) NOT NULL,
  `r_ampm` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tourist`
--

CREATE TABLE `tourist` (
  `tour_id` int(11) NOT NULL,
  `tour_fN` varchar(50) NOT NULL,
  `tour_mN` varchar(50) NOT NULL,
  `tour_lN` varchar(50) NOT NULL,
  `tour_address` varchar(255) NOT NULL,
  `tour_contact` varchar(15) NOT NULL,
  `tour_un` varchar(50) NOT NULL,
  `tour_up` varchar(35) NOT NULL,
  `user_type` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tourist`
--

INSERT INTO `tourist` (`tour_id`, `tour_fN`, `tour_mN`, `tour_lN`, `tour_address`, `tour_contact`, `tour_un`, `tour_up`, `user_type`) VALUES
(3, 'Dorothy', 'Handugan', 'Alberca', 'st.bernard', '09958378739', 'baby', 'dd16cde0e70366049724a2d23130ca36', '2'),
(5, 'desa', 'odarbe', 'Rupin', 'samoje', '12460841412', 'desa', '0fe510c490b1058faf4380510fb14eb2', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `boats`
--
ALTER TABLE `boats`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`r_id`,`b_id`,`tour_id`);

--
-- Indexes for table `tourist`
--
ALTER TABLE `tourist`
  ADD PRIMARY KEY (`tour_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `boats`
--
ALTER TABLE `boats`
  MODIFY `b_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tourist`
--
ALTER TABLE `tourist`
  MODIFY `tour_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
